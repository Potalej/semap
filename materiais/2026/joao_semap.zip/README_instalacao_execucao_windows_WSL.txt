##################################################
## INSTALAÇÃO DA BIBLIOTECA PYMGRIT             ##
##################################################

####################
## 1 - INSTALAÇÃO ##
####################

1.0. Caso você já tenha MPI instalado, provavelmente é suficiente executar

     pip install mpi4py pymgrit

     Caso contrário, siga as instruções 1.1 - 1.3 a seguir.


1.1. Instalação do Miniconda (gerenciador de pacotes Python):

     1.1.a. Abre o WSL (subsistema deLinux no Windows) e baixe o instalador .exe no site oficial da Anaconda:
            wget https://repo.anaconda.com/miniconda/Miniconda3-latest-Linux-x86_64.sh

     1.1.b. Execute o instalador e siga os passos.

                bash Miniconda3-latest-Linux-x86_64.sh

     1.1.c. Teste a instalçao:

                conda --version


1.2. Instalação do MPI:

     1.2.a. Ainda no WSL, execute:

                sudo apt-get update
                sudo apt-get install openmpi-bin openmpi-common libopenmpi-dev

     1.2.b. Verifique que a instalação foi feita corretamente executando

                mpiexec -help


1.3. Criação do ambiente conda para execução do FEniCSx

     1.3.a. No WSL, execute

                conda create -n fenicsx-env python=3.11
                conda activate fenicsx-env

1.4. Instalação do FEniCSx e do JupyterLab dentro do ambiente onda

     1.4.a. No WSL, execute

                conda install -c conda-forge fenics-dolfinx
                conda install -c conda-forge pyvista
                conda install -c conda-forge jupyterlab
                conda install -c conda-forge notebook
                pip install trame trame-vtk trame-vuetify ipywidgets matplotlib pyvista meshio h5py

     1.4.b. Criação de um Kernel no Jupyter permitindo executar FEniCSx: no WSL, execute

                python -m ipykernel install --user --name=fenicsx-env --display-name "Python (fenicsx)"


1.5 [OPCIONAL] Instalação do gmsh (gerador de malha)

     Caso queira modificar ou produzir novas malhas para testar no FEniCSx:

     1.5.a. Abra o WSL e execute

                sudo apt-get install gmsh

##################
## 2 - EXECUÇÃO ##
##################

2.1 Execução

     2.1.a. Abra o WSL e vá até a pasta contendo o arquivo .ipynb. Execute

                jupyter notebook

            e selecione o arquivo que se deseja abrir.

2.2 [OPCIONAL] Geração de malhas

     As malhas para os exemplos disponíveis no notebook já estão fornecidas no arquivo .zip.
     Caso queira modificar a malha, siga as instruções abaixo e consulte a documentação do gmsh (https://gmsh.info/doc/texinfo/)


     2.2.a. Após produzir o arquivo malha.geo (arquivo que contém as instruções para geração da malha), abra o WSL e execute

         gmsh [nome_malha].geo -2 -o [nome_malha].msh

     2.2.b. Converta a malha para o formato .xdmf executando

         python converter_malha.py [nome_malha]
