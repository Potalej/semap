import meshio
import numpy as np
import sys

nome_malha = sys.argv[1]

# Ler da malha
m = meshio.read(nome_malha + ".msh")

# Considerar apenas triângulos
triangles = m.get_cells_type("triangle")

# Evitar repetição de triângulos
triangle_data = m.cell_data_dict["gmsh:geometrical"]["triangle"]
mask = triangle_data == 1  # tag da surface 1
triangles_filtrados = triangles[mask]

## Converter a malha
malha = meshio.Mesh(
    points=m.points[:, :2],  # Remover a coordenada z
    cells=[("triangle", triangles_filtrados)]
)

## Salvar a malha
meshio.write(nome_malha + ".xdmf", malha)
